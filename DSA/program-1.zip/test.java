/*Write a Java program to compute the Fibonacci number for a given n
ex:

input = 2
output =1

first two elements 0 1. so print last element ie nth fibonacci number is 1

input = 3
output =2
first three elements 0 1 1 Write a Java program to compute the Fibonacci number for a given 1

input  =50
output =12586269025
*/
import java.util.Scanner;
import java.math.BigInteger;
public class test {
    public static BigInteger fibonacci(int n) {
        if (n <= 1) {
            return BigInteger.valueOf(n);
}
        BigInteger a = BigInteger.ZERO;
        BigInteger b = BigInteger.ONE;
        BigInteger c;
        for (int i = 2; i <= n; i++) {
            c = a.add(b);
            a = b;
            b = c;
}
        return b;
}
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        System.out.println(fibonacci(n));

}}


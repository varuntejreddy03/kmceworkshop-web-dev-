import java.util.Scanner;
import java.math.BigInteger;
public class fact{
static BigInteger f(int x){
if(x==0||x==1){
  return BigInteger.ONE;
}
  return BigInteger.valueOf(x).multiply(f(x-1));
}
  public static void main(String[] args){
    Scanner s=new Scanner(System.in);
    int a=s.nextInt();
    BigInteger res=f(a);
    System.out.println(res);
}
}
import java.util.Scanner;
public class climb {
    static long climb(int n) {
        if (n == 0 || n == 1) {
            return 1;
}
        return climb(n - 1) + climb(n - 2);
}
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int s = sc.nextInt();
        System.out.println(climb(s));
}

}